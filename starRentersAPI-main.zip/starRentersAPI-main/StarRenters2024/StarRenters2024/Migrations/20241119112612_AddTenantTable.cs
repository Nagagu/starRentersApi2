﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StarRenters2024.Migrations
{
    public partial class AddTenantTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
